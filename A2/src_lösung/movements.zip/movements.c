/**
 * @file movements.c
 *
 * @brief Bewegungs-Test-Funktionen.
 *
 *  Die Ausgabe auf der seriellen Schnittstelle kann per " #define PRINT_OUTPUT "
 *  mitkompiliert werden.
 *
 * @author Peter Rudolph
 *
 * @date 16.10.2012 10:51:24
 */

// print output
//#define PRINT_OUTPUT
#include <util/delay.h>

#include "movements.h"
/**
 * @brief array containing current ADC values
 */
uint16_t encoderADC[2] = { 0, 0 };

void updateEncoderADCs() {
    /// due to 10 bit resolution we need an auxiliary register\n so we have to add high and low register
    static uint16_t adcl_value = 0;
    /// disable MUXs -> right transistor; see manual, p. 199
    ADMUX &= ~(1 << MUX0 | 1 << MUX1 | 1 << MUX2 | 1 << MUX3);
    /// set ADSC bit to 1 -> start the conversion
    ADCSRA |= (1 << ADSC);
    while (!(ADCSRA & (1 << ADIF)))
        ; /// wait till conversion finished
    /// clear ADC interrupt flag (ADIF)
    ADCSRA |= (1 << ADIF);
    /// get right value from registers
    adcl_value = ADCL;
    encoderADC[RIGHT] = (ADCH << 8) + adcl_value; // ADCH = high, ADCL = low, see page 201
    /// enable MUX0 -> left transistor; see manual, p. 199
    ADMUX &= ~(1 << MUX1 | 1 << MUX2 | 1 << MUX3);
    ADMUX |= (1 << MUX0);
    ///set the ADSC bit to 1 - start the conversation
    ADCSRA |= (1 << ADSC);
    while (!(ADCSRA & (1 << ADIF)))
        ; ///wait for the conversation to stop
    /// clear ADC interrupt flag (ADIF)
    ADCSRA |= (1 << ADIF);
    /// get left value from registers
    adcl_value = ADCL;
    encoderADC[LEFT] = (ADCH << 8) + adcl_value; // ADCH = high, ADCL = low, see page 201
}

void turnInPlace(int16_t degrees) {
    /// init variables
    int16_t counts = 0;
    uint8_t encoder_state = BLACK;
    uint8_t last_encoder_state = BLACK;
    /// set counts to turn to apply given degrees
    int16_t counts_to_turn = ((abs(degrees*10)) / 22);
    /// set motor directions according to degrees sign
    if (degrees < 0)
        MotorDir(FWD, RWD);
    else
        MotorDir(RWD, FWD);
    /// get initial encoder value
    updateEncoderADCs();
    /// check left encoder -> black/white
    if (encoderADC[LEFT] > ODO_SENSITIVITY_LEFT_WHITE) {
        // set state to white
        last_encoder_state = WHITE;
    } else {
        // set state to black
        last_encoder_state = BLACK;
    }
    /// set motor speeds
    MotorSpeed(SPEED, SPEED);
    /// enter movement loop
    while (counts < counts_to_turn) {
        /// update encoder values
        updateEncoderADCs();
        /// check left encoder -> black/white
        if (encoderADC[LEFT] > ODO_SENSITIVITY_LEFT_WHITE) {
            // set state to white
            encoder_state = WHITE;
        } else if(encoderADC[LEFT] < ODO_SENSITIVITY_LEFT_BLACK) {
            // set state to black
            encoder_state = BLACK;
        }
        /// increment counts if encoder state switched
        if (encoder_state != last_encoder_state) {
            // increment counts
            counts++;
            // update state
            last_encoder_state = encoder_state;
        }
    }
    /// stop motors on finished movement
    MotorSpeed(BREAK, BREAK);
}

void driveStraight(int16_t centimeters) {
    /// init variables
    int16_t counts = 0;
    uint8_t encoder_state = BLACK;
    uint8_t last_encoder_state = BLACK;
    /// set movement parameter to apply given degrees
    int16_t counts_to_drive = (int16_t) (abs(centimeters) * 10 / 2);
    /// set motor directions according to degrees sign
    if (centimeters > 0)
        MotorDir(FWD, FWD);
    else
        MotorDir(RWD, RWD);    /// get initial encoder value
    updateEncoderADCs();
    /// check left encoder -> black/white
    if (encoderADC[LEFT] > ODO_SENSITIVITY_LEFT_WHITE) {
        // set state to white
        encoder_state = WHITE;
    } else if(encoderADC[LEFT] < ODO_SENSITIVITY_LEFT_BLACK) {
        // set state to black
        encoder_state = BLACK;
    }
    /// set motor speeds
    MotorSpeed(SPEED, SPEED);
    /// enter movement loop
    while (counts < counts_to_drive) {
        /// update encoder values
        updateEncoderADCs();
        /// check left encoder -> black/white
        if (encoderADC[LEFT] > ODO_SENSITIVITY_LEFT) {
            // set state to white
            encoder_state = WHITE;
        } else {
            // set state to black
            encoder_state = BLACK;
        }
        /// increment counts if encoder state switched
        if (encoder_state != last_encoder_state) {
            // increment counts
            counts++;
            // update state
            last_encoder_state = encoder_state;
        }
    }
    /// stop motors on finished movement
    MotorSpeed(BREAK, BREAK);
}

void driveEquilateralTriangle(int16_t centimeters){
	int corner = 0;
    for (; corner < 3; corner++) {
        /// drive 20 centimeters
        driveStraight(20);
        /// turn 120 degrees
        turnInPlace(120);
    }
}
