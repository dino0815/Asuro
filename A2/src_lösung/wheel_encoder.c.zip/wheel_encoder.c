/**
 * @file wheel_encoder.c
 *
 * @brief Programm zum Testen der ASURO Rad-"Encoder"-Einheit.
 *
 *  Die Ausgabe auf der seriellen Schnittstelle kann per " #define PRINT_OUTPUT "
 *  mitkompiliert werden.
 *
 * @author Adrian Calma\n
 *         Peter Rudolph
 *
 * @date 16.10.2012 10:51:24
 */

// system includes
#include <avr/io.h>

// project includes
#include "asuro.h"

/**
 * @brief set bit in variable
 * @param a target variable
 * @param b bit number
 */
#define BIT_SET(a,b) ((a) |= (1<<(b)))
/**
 * @brief clear bit in variable
 * @param a target variable
 * @param b bit number
 */
#define BIT_CLEAR(a,b) ((a) &= ~(1<<(b)))
/**
 * @brief flip bit in variable
 * @param a target variable
 * @param b bit number
 */
#define BIT_FLIP(a,b) ((a) ^= (1<<(b)))
/**
 * @brief check bit in variable
 * @param a target variable
 * @param b bit number
 */
#define BIT_CHECK(a,b) ((a) & (1<<(b)))
/**
 * @brief set bitmask in variable
 * @param x target variable
 * @param y bitmask
 */
#define BITMASK_SET(x,y) ((x) |= (y))
/**
 * @brief clear bitmask in variable
 * @param x target variable
 * @param y bitmask
 */
#define BITMASK_CLEAR(x,y) ((x) &= (~(y)))
/**
 * @brief flip bitmask in variable
 * @param x target variable
 * @param y bitmask
 */
#define BITMASK_FLIP(x,y) ((x) ^= (y))
/**
 * @brief check bitmask in variable
 * @param x target variable
 * @param y bitmask
 */
#define BITMASK_CHECK(x,y) ((x) & (y))
/**
 * @brief right ADC threshold between black and white
 */
#define ODO_SENSITIVITY_RIGHT 650
/**
 * @brief  left ADC threshold between black and white
 */
#define ODO_SENSITIVITY_LEFT 450

/**
 * @brief  array containing both ADC values
 */
uint16_t encoderADC[2];

// function prototypes
/**
 * @brief turn on both wheel encoder LEDs
 */
void turnOnEncoderLEDs(void);
/**
 * @brief turn off Status LED
 */
void turnOffStatusLED(void);
/**
 * @brief enable photo-transistors as input
 */
void enableADCInput(void);
/**
 * @brief initialize ADCs
 */
void initADC(void);
/**
 * @brief update ADC values from both wheels
 */
void updateEncoderADCs(void);

/**
 * @brief  program entry point
 * @return  exit_status (never reached)
 */
int main(void) {
    /// init ASURO
    Init();
    /// turn off status LED
    turnOffStatusLED();
    /// turn on both wheel LEDs
    turnOnEncoderLEDs();
    /// enable input pins
    enableADCInput();
    /// initialize ADC
    initADC();
    /// enter main loop
    for (;;) {
        /// update encoder values
        updateEncoderADCs();
        /// check right encoder -> enable/disable PD6
        if (encoderADC[RIGHT] > ODO_SENSITIVITY_RIGHT) {
            // enable PD6 (front LED)
            BIT_SET(PORTD,PIND6);
        } else {
            // disable PD6 (front LED)
            BIT_CLEAR(PORTD,PIND6);
        }
        /// check left encoder -> enable/disable PD2
        if (encoderADC[LEFT] > ODO_SENSITIVITY_LEFT) {
            // enable PD2 (status LED red)
            BIT_SET(PORTD,PIND2);
        } else {
            // disable PD2 (status LED red)
            BIT_CLEAR(PORTD,PIND2);
        }
        /// continue main loop
#ifdef PRINT_OUTPUT
        /// print output
        SerPrint("\nenc_adc: left | right\n");
        PrintInt(encoderADC[LEFT]);
        SerPrint(" | ");
        PrintInt(encoderADC[RIGHT]);
#endif
    }
    /// return exit status (never reached)
    return 0;
}

void turnOnEncoderLEDs() {
    /// enable PD7
    ODOMETRIE_LED_ON;
}

void turnOffStatusLED() {
    /// disable PD2
    GREEN_LED_OFF;
    /// disable PB0
    RED_LED_OFF;
}

void enableADCInput() {
    /// set PC0 (ADC0) and PC1 (ADC1) data direction to input
    DDRC &= ~((1 << PC0) | (1 << PC1));
}

void initADC() {
    /// reset ADC configuration
    ADMUX = 0;
    ADCSRA = 0;
    // REFS1=0 && REFS0=1 -> AVCC with external capacitor at AREF pin (see manual, p. 199)
    /// set AVCC with external capacitor at AREF pin (see manual, p. 199)
    ADMUX |= (1 << REFS0);
    /// enable ADC
    ADCSRA |= (1 << ADEN);
    /// set pre-scaler to clock/128
    ADCSRA |= (1 << ADPS0 | 1 << ADPS1 | 1 << ADPS2);
}

void updateEncoderADCs() {
    /// due to 10 bit resolution we need an auxiliary register\n so we have to add high and low register
    static uint16_t adcl_value = 0;
    /// disable MUXs -> right encoder; see manual, p. 199
    ADMUX &= ~(1 << MUX0 | 1 << MUX1 | 1 << MUX2 | 1 << MUX3);
    /// set ADSC bit to 1 -> start the conversion
    ADCSRA |= (1 << ADSC);
    while (!(ADCSRA & (1 << ADIF)))
        ; /// wait till conversion finished
    /// clear ADC interrupt flag (ADIF)
    ADCSRA |= (1 << ADIF);
    /// get right value from registers
    adcl_value = ADCL;
    encoderADC[RIGHT] = (ADCH << 8) + adcl_value; // ADCH = high, ADCL = low, see page 201
    /// enable MUX0 -> left encoder; see manual, p. 199
    ADMUX &= ~(1 << MUX1 | 1 << MUX2 | 1 << MUX3);
    ADMUX |= (1 << MUX0);
    ///set the ADSC bit to 1 - start the conversation
    ADCSRA |= (1 << ADSC);
    while (!(ADCSRA & (1 << ADIF)))
        ; ///wait for the conversation to stop
    /// clear ADC interrupt flag (ADIF)
    ADCSRA |= (1 << ADIF);
    /// get left value from registers
    adcl_value = ADCL;
    encoderADC[LEFT] = (ADCH << 8) + adcl_value; // ADCH = high, ADCL = low, see page 201
}
